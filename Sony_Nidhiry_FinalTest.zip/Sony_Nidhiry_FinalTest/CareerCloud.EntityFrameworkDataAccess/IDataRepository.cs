﻿namespace CareerCloud.EntityFrameworkDataAccess
{
    public interface IDataRepository<T> where T : class
    {
    }
}