﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CareerCloud.Pocos
{
    public interface IPoco
    {
        Guid Id { get; set; }
    }
}
